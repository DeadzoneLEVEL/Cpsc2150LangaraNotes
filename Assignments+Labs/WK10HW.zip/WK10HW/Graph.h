#ifndef GRAPH_H
#define GRAPH_H

#include <iostream>
#include <vector>
#include <ctime>
#include <queue>
// using namespace std;

class Edge{
public:
    // assume u and v are two vertices 
    // vertices are zero-indexed
    int u;
    int v;

    Edge(){
        u = -1; // invalid vertex index
        v = -1; // invalid vertex index
    }

    Edge(int _u, int _v){
        u = _u;
        v = _v;
    }

    const Edge& operator=(const Edge&rhs){
        this->u=rhs.u;
        this->v=rhs.v;
        return *this;
    }

    friend std::ostream& operator<<(std::ostream &out,const Edge &e){
        out<<"{"<<e.u<<","<<e.v<<"}";
        return out;
    }
    bool operator==(const Edge&rhs){
        bool control=true;
        if(this->u!=rhs.u){
            control=false;
        }
        if(this->v!=rhs.v){
            control=false;
        }
        return control;
    }

};

class vertex {
    public:
        int u;
        int v;
        bool wall;
        vertex(){
            u=-1;
            v=-1;
            wall=false;
        }
        
        vertex(int _u, int _v, bool _wall) {
            u = _u;
            v = _v;
            wall = _wall;
        }

        const vertex& operator=(const vertex&rhs){
            this->u=rhs.u;
            this->v=rhs.v;
            this->wall=rhs.wall;
            return *this;
        }
        friend std::ostream& operator<<(std::ostream &out,const vertex &e){
            out<<"{"<<e.u<<","<<e.v<<":"<<std::boolalpha<<e.wall<<"}";
            return out;
        }

        bool operator==(const vertex &rhs){
            bool control=true;
            if(this->u!=rhs.u){
                control=false;
            }
            if(this->v!=rhs.v){
                control=false;
            }
            if(this->wall!=rhs.wall){
                control=false;
            }
            return control;
        }
};

class Graph{
private:
    std::vector<vertex> vertices;
    std::vector<std::vector<vertex>> adjacencyList;
    std::vector<Edge> edgeList;
    int size;
public:
    Graph(){
    }

    Graph(unsigned adjacencyMatrix[4][4], int n){
        // adjacencyMatrix has dimension n x n with zeroes along the main diagonal
        // assume row 0 is for vertex 0, row 1 is for vertex 1 and so on

        // TASKS: add methods to do the following:
        // build vertices, adjacencyList, edgeList using adjacencyMatrix.
        size=n;
        makeVertices(adjacencyMatrix,n);
        makeAdjacencyList(adjacencyMatrix,n);
    }
    bool outOfBounds(int x,int y,int n){
        if(x<0||x>=n||y<0||y>=n){
            return true;
        }else{
            return false;
        }
    }
    void makeAdjacencyList(unsigned adjacencyMatrix[4][4],int n){
        adjacencyList.resize(vertices.size());
        vertex tmp;
        int index = 0;
        for(int row=0;row<n;row++){
            for(int col=0;col<n;col++){
                if(!outOfBounds(row,col+1,n)){
                    tmp=vertex(row,col+1,adjacencyMatrix[row][col]==0);
                    adjacencyList[index].push_back(tmp);
                }
                if(!outOfBounds(row,col-1,n)){
                    tmp=vertex(row,col-1,adjacencyMatrix[row][col]==0);
                    adjacencyList[index].push_back(tmp);
                }
                if(!outOfBounds(row+1,col,n)){
                    tmp=vertex(row+1,col,adjacencyMatrix[row][col]==0);
                    adjacencyList[index].push_back(tmp);
                }
                if(!outOfBounds(row-1,col,n)){
                    tmp=vertex(row-1,col,adjacencyMatrix[row][col]==0);
                    adjacencyList[index].push_back(tmp);
                }

                // adjacencyList[row].push_back(vertex());
                index++;
            }
        }
        return;
    }
    void makeVertices(unsigned adjacencyMatrix[4][4],int n){
        // vertices.resize(n*n);
        vertex tmp;
        for (int row=0;row<n;row++) {
            for (int col=0;col<n;col++) {
                tmp=vertex(row,col,adjacencyMatrix[row][col]==0);
                vertices.push_back(tmp);
            }
        }
        return;
    }
    void displayVertices() {
        std::cout<<"Vertices: \n";
        for (unsigned i=0;i<vertices.size();i++) {
            std::cout<<vertices[i]<<"\n";
        }
        std::cout<<"\n";
        return;
    }

    void displayAdjacencyList() {
        std::cout<<"Adjancency List: \n";
        unsigned indexX=0,indexY=0;
        for (unsigned row=0;row<adjacencyList.size();row++) {
            std::cout<<"("<<indexX<<","<<indexY<<"):";
            for (unsigned col=0;col<adjacencyList[row].size();col++) {
                std::cout<<adjacencyList[row][col]<<" ";
            }
            std::cout<<"\n";
            indexY++;
            if(indexY==size){
                indexX++;
                indexY=0;
            }
        }
        return;
    }
    void pathFinder(){

    }
    void pathFinder(int current,std::vector<int> visited,int size,bool &key){
        
        return;
    }
    bool existInVect(vertex val,std::vector<vertex> vec){
        bool control=false;
        for(unsigned i=0;i<vec.size();i++){
            if(vec[i]==val){
                control=true;
            }
        }
        return control;
    }

};



#endif